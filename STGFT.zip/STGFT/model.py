"""
Spatial-Temporal Graph Fusion Transformer (STGFT) for River Water Quality Prediction

Inspired by:
"Long-Term Water Quality Prediction With Transformer-Based Spatial-Temporal Graph Fusion"
Jing Bi et al., IEEE Transactions on Automation Science and Engineering, 2025.

Architecture Overview:
1. Temporal Attention Encoder (TAE): Transformer-based temporal self-attention across sequence time steps.
2. Spatial Attention Encoder (SAE): Multi-head attention across spatial/multivariate parameter nodes.
3. Adaptive Dynamic Adjacency Matrix Generator (ADMG):
   - Predefined Graph (A_pre): Constructed from empirical inter-parameter correlation across monitoring stations.
   - Adaptive Graph (A_adp): Learned parameterized graph capturing intrinsic spatial relationships.
   - Dynamic Graph (A_dyn): Dynamic graph conditioned on temporal-spatial feature states.
4. Multi-Graph Fusion Layer: 3 parallel Graph Convolutional Networks (GCNs) dynamically fused via learnable weights.
5. Spatial-Temporal Fusion & Predictor: Fuses temporal and spatial representations to forecast DO, pH, and BOD.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class GraphConvolution(nn.Module):
    """
    Standard Spectral Graph Convolution layer:
    Z = ReLU(A * X * W + b)
    """
    def __init__(self, in_features, out_features):
        super().__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        self.bias = nn.Parameter(torch.FloatTensor(out_features))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
        bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
        nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x, adj):
        # x: (batch_size, num_nodes, in_features)
        # adj: (num_nodes, num_nodes) or (batch_size, num_nodes, num_nodes)
        support = torch.matmul(x, self.weight)
        if adj.dim() == 2:
            out = torch.einsum("nm,bnk->bmk", adj, support)
        else:
            out = torch.matmul(adj, support)
        return F.relu(out + self.bias)


class AdaptiveDynamicAdjacencyGenerator(nn.Module):
    """
    Adaptive Dynamic Adjacency Matrix Generator (ADMG) as described by Jing Bi et al. (2025).
    Generates:
    - Predefined graph (A_pre): empirical correlation graph from river station records.
    - Adaptive graph (A_adp): learned node embedding similarity matrix.
    - Dynamic graph (A_dyn): input-conditioned dynamic matrix combining spatial state and predefined graph.
    """
    def __init__(self, num_nodes=3, node_dim=16, spatial_dim=64):
        super().__init__()
        self.num_nodes = num_nodes
        
        # Adaptive graph parameters (learned node embeddings)
        self.node_embed1 = nn.Parameter(torch.randn(num_nodes, node_dim))
        self.node_embed2 = nn.Parameter(torch.randn(num_nodes, node_dim))
        
        # Dynamic graph projection
        self.dynamic_proj = nn.Linear(spatial_dim, node_dim)
        
        # Predefined graph buffer based on empirical correlation of DO, pH, BOD
        # Empirical correlation matrix: DO-pH: ~0.0986, DO-BOD: ~-0.2678 (abs 0.2678), pH-BOD: ~0.3588
        base_adj = torch.tensor([
            [1.0000, 0.0986, 0.2678],
            [0.0986, 1.0000, 0.3588],
            [0.2678, 0.3588, 1.0000]
        ], dtype=torch.float32)
        # Symmetric degree normalization: D^{-1/2} A D^{-1/2}
        deg = torch.diag(torch.pow(base_adj.sum(dim=1), -0.5))
        norm_base_adj = torch.matmul(torch.matmul(deg, base_adj), deg)
        self.register_buffer("predefined_adj", norm_base_adj)

    def forward(self, spatial_repr):
        # spatial_repr: (batch_size, num_nodes, spatial_dim)
        batch_size = spatial_repr.size(0)
        
        # 1. Predefined Graph
        A_pre = self.predefined_adj  # (num_nodes, num_nodes)
        
        # 2. Adaptive Graph: Softmax(ReLU(E1 * E2^T))
        adp_score = F.relu(torch.matmul(self.node_embed1, self.node_embed2.t()))
        A_adp = F.softmax(adp_score, dim=-1)  # (num_nodes, num_nodes)
        
        # 3. Dynamic Graph: conditioned on spatial features + predefined prior
        # Map spatial representation to node embedding space
        dyn_feat = self.dynamic_proj(spatial_repr)  # (batch_size, num_nodes, node_dim)
        dyn_score = torch.matmul(dyn_feat, dyn_feat.transpose(1, 2))  # (batch_size, num_nodes, num_nodes)
        dyn_score = F.relu(dyn_score + A_pre.unsqueeze(0))
        A_dyn = F.softmax(dyn_score, dim=-1)  # (batch_size, num_nodes, num_nodes)
        
        return A_pre, A_adp, A_dyn


class SpatialAttentionEncoder(nn.Module):
    """
    Spatial Attention Encoder (SAE):
    Computes cross-node / spatial attention to model spatial correlation among water quality monitoring parameters.
    """
    def __init__(self, in_features=12, hidden_dim=64, num_heads=2, dropout=0.1):
        super().__init__()
        self.in_proj = nn.Linear(in_features, hidden_dim)
        self.attn = nn.MultiheadAttention(embed_dim=hidden_dim, num_heads=num_heads, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(hidden_dim)
        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim)
        )
        self.norm2 = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        # x: (batch_size, seq_len=12, num_nodes=3)
        # Transpose to (batch_size, num_nodes=3, seq_len=12)
        node_input = x.transpose(1, 2)
        h = self.in_proj(node_input)  # (batch_size, num_nodes, hidden_dim)
        attn_out, _ = self.attn(h, h, h)
        h = self.norm(h + attn_out)
        ffn_out = self.ffn(h)
        h = self.norm2(h + ffn_out)
        return h  # (batch_size, num_nodes, hidden_dim)


class TemporalAttentionEncoder(nn.Module):
    """
    Temporal Attention Encoder (TAE):
    Transformer-based temporal self-attention across 12 monthly time steps.
    """
    def __init__(self, num_features=3, hidden_dim=64, seq_len=12, num_heads=4, num_layers=2, dropout=0.1):
        super().__init__()
        self.embedding = nn.Linear(num_features, hidden_dim)
        self.pos_embedding = nn.Parameter(torch.randn(1, seq_len, hidden_dim) * 0.02)
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 2,
            dropout=dropout,
            batch_first=True,
            activation="relu"
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        # x: (batch_size, seq_len=12, num_features=3)
        h = self.embedding(x) + self.pos_embedding
        h = self.transformer(h)
        return self.norm(h)  # (batch_size, seq_len, hidden_dim)


class MultiGraphFusionLayer(nn.Module):
    """
    Multi-Graph Fusion Layer:
    Adopts 3 parallel GCNs for Predefined, Adaptive, and Dynamic graphs.
    Fuses the representations via learnable fusion weights alpha, beta, gamma.
    """
    def __init__(self, in_features=64, out_features=64):
        super().__init__()
        self.gcn_pre = GraphConvolution(in_features, out_features)
        self.gcn_adp = GraphConvolution(in_features, out_features)
        self.gcn_dyn = GraphConvolution(in_features, out_features)
        
        # Learnable weighting coefficients
        self.fusion_weights = nn.Parameter(torch.ones(3) / 3.0)

    def forward(self, node_features, A_pre, A_adp, A_dyn):
        z_pre = self.gcn_pre(node_features, A_pre)
        z_adp = self.gcn_adp(node_features, A_adp)
        z_dyn = self.gcn_dyn(node_features, A_dyn)
        
        weights = F.softmax(self.fusion_weights, dim=0)
        z_fused = weights[0] * z_pre + weights[1] * z_adp + weights[2] * z_dyn
        return z_fused


class STGFT(nn.Module):
    """
    Spatial-Temporal Graph Fusion Transformer (STGFT)
    
    Combines:
    - Temporal Attention Encoder (TAE)
    - Spatial Attention Encoder (SAE)
    - Adaptive Dynamic Adjacency Matrix Generator (ADMG)
    - Multi-Graph Fusion Layer (3 parallel GCNs)
    - Spatio-Temporal Gated Fusion
    - Multi-target Output Decoder (DO, pH, BOD)
    """
    def __init__(
        self,
        num_features=3,
        seq_len=12,
        hidden_dim=64,
        num_heads_t=4,
        num_heads_s=2,
        num_layers_t=2,
        dropout=0.1
    ):
        super().__init__()
        self.num_features = num_features
        self.seq_len = seq_len
        self.hidden_dim = hidden_dim
        
        # 1. Temporal Attention Encoder
        self.tae = TemporalAttentionEncoder(
            num_features=num_features,
            hidden_dim=hidden_dim,
            seq_len=seq_len,
            num_heads=num_heads_t,
            num_layers=num_layers_t,
            dropout=dropout
        )
        
        # 2. Spatial Attention Encoder
        self.sae = SpatialAttentionEncoder(
            in_features=seq_len,
            hidden_dim=hidden_dim,
            num_heads=num_heads_s,
            dropout=dropout
        )
        
        # 3. Adaptive Dynamic Adjacency Matrix Generator
        self.admg = AdaptiveDynamicAdjacencyGenerator(
            num_nodes=num_features,
            node_dim=16,
            spatial_dim=hidden_dim
        )
        
        # 4. Multi-Graph Fusion Layer
        self.multi_graph_fusion = MultiGraphFusionLayer(
            in_features=hidden_dim,
            out_features=hidden_dim
        )
        
        # 5. Spatial-Temporal Gated Fusion
        self.temporal_proj = nn.Linear(hidden_dim, hidden_dim)
        self.spatial_proj = nn.Linear(num_features * hidden_dim, hidden_dim)
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Sigmoid()
        )
        
        # 6. Output Decoder for predicting DO, pH, BOD
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_features)
        )

    def forward(self, x):
        # Input x: (batch_size, 12, 3)
        batch_size = x.size(0)
        
        # Step 1: Temporal Attention Encoding
        h_temporal = self.tae(x)  # (batch_size, 12, hidden_dim)
        h_t_last = h_temporal[:, -1, :]  # (batch_size, hidden_dim)
        
        # Step 2: Spatial Attention Encoding
        h_spatial = self.sae(x)  # (batch_size, 3, hidden_dim)
        
        # Step 3: Adaptive Dynamic Adjacency Matrices
        A_pre, A_adp, A_dyn = self.admg(h_spatial)
        
        # Step 4: Multi-Graph GCN Fusion
        z_spatial = self.multi_graph_fusion(h_spatial, A_pre, A_adp, A_dyn)  # (batch_size, 3, hidden_dim)
        z_flat = z_spatial.reshape(batch_size, -1)  # (batch_size, 3 * hidden_dim)
        
        # Step 5: Spatio-Temporal Gated Fusion
        t_feat = self.temporal_proj(h_t_last)
        s_feat = self.spatial_proj(z_flat)
        gate_val = self.gate(torch.cat([t_feat, s_feat], dim=-1))
        fused = gate_val * t_feat + (1.0 - gate_val) * s_feat
        
        # Step 6: Multi-target Prediction
        out = self.decoder(fused)  # (batch_size, 3)
        return out


if __name__ == "__main__":
    model = STGFT()
    test_x = torch.randn(8, 12, 3)
    test_out = model(test_x)
    print("STGFT Model initialized successfully.")
    print(f"Input shape : {test_x.shape}")
    print(f"Output shape: {test_out.shape}")
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {total_params:,}")
