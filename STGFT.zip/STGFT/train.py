"""
Training Script for STGFT (Spatial-Temporal Graph Fusion Transformer)

Paper: "Long-Term Water Quality Prediction With Transformer-Based Spatial-Temporal Graph Fusion"
       Jing Bi et al., IEEE Transactions on Automation Science and Engineering, 2025.

Graph Construction Strategy:
- The dataset records multivariate water quality (DO, pH, BOD) across 64 filtered monitoring stations
  along the Ganga River basin across 5 Indian states.
- Because physical GPS coordinates are not explicitly given in the dataset, the spatial predefined graph (A_pre)
  is rigorously constructed from the empirical cross-correlation matrix between water quality indicators
  across all monitoring stations in the historical training data.
- The Adaptive Dynamic Adjacency Matrix Generator (ADMG) augments this with an adaptive learned graph (A_adp)
  and a dynamically conditioned graph (A_dyn), preventing restriction to a static topology.
"""

import sys
import os
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

# Ensure local imports work regardless of execution directory
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
sys.path.append(str(CURRENT_DIR))

from model import STGFT


def load_dataset():
    """
    Loads training, validation, and test data.
    Ensures exact consistency with the experiment setup:
    X_train: (4460, 12, 3), y_train: (4460, 3)
    X_val:   (1116, 12, 3), y_val:   (1116, 3)
    X_2025:  (1195, 12, 3), y_2025:  (1195, 3)
    """
    processed_dir = PROJECT_ROOT / "River_Water_Quality_Project - Copy" / "Processed_Data"
    
    if (processed_dir / "X_train_scaled.npy").exists():
        X_train = np.load(processed_dir / "X_train_scaled.npy")
        y_train = np.load(processed_dir / "y_train_scaled.npy")
        X_val = np.load(processed_dir / "X_val_scaled.npy")
        y_val = np.load(processed_dir / "y_val_scaled.npy")
        scaler_X = joblib.load(processed_dir / "scaler_X.pkl")
        scaler_y = joblib.load(processed_dir / "scaler_y.pkl")
        X_2025_raw = np.load(processed_dir / "X_2025.npy")
        y_2025_raw = np.load(processed_dir / "y_2025.npy")
    else:
        raise FileNotFoundError(f"Processed dataset directory not found at {processed_dir}")

    # Scale 2025 test input identically using the fitted scaler_X
    samples_test, seq_len, num_feat = X_2025_raw.shape
    X_2025_scaled = scaler_X.transform(X_2025_raw.reshape(-1, num_feat)).reshape(samples_test, seq_len, num_feat)

    return X_train, y_train, X_val, y_val, X_2025_scaled, y_2025_raw, scaler_X, scaler_y


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    # Set seeds for reproducibility
    torch.manual_seed(42)
    np.random.seed(42)

    X_train, y_train, X_val, y_val, X_2025_scaled, y_2025_raw, scaler_X, scaler_y = load_dataset()

    print("=" * 50)
    print("TRAIN DATA")
    print("=" * 50)
    print("X_train :", X_train.shape)
    print("y_train :", y_train.shape)

    print("\n" + "=" * 50)
    print("VALIDATION DATA")
    print("=" * 50)
    print("X_val :", X_val.shape)
    print("y_val :", y_val.shape)

    print("\n" + "=" * 50)
    print("STGFT GRAPH CONTEXT & SETUP")
    print("=" * 50)
    print("Model: Spatial-Temporal Graph Fusion Transformer (STGFT)")
    print("Reference: Jing Bi et al., IEEE TASE 2025")
    print("Graph Structure: 3 parallel GCNs fused via ADMG (Adaptive Dynamic Adjacency)")
    print("  - Predefined Graph (A_pre): Empirical biochemical correlation from 64 river monitoring stations")
    print("  - Adaptive Graph (A_adp): Data-driven parameter embeddings learning unconstrained relationships")
    print("  - Dynamic Graph (A_dyn): Dynamic state-conditioned graph capturing time-varying dependencies")

    # PyTorch Tensors & DataLoaders
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
    X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
    y_val_tensor = torch.tensor(y_val, dtype=torch.float32)

    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    val_dataset = TensorDataset(X_val_tensor, y_val_tensor)

    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nUsing Device : {device}")

    model = STGFT(
        num_features=3,
        seq_len=12,
        hidden_dim=64,
        num_heads_t=4,
        num_heads_s=2,
        num_layers_t=2,
        dropout=0.1
    ).to(device)

    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    epochs = 40
    patience = 8
    patience_counter = 0
    best_val_loss = float("inf")

    model_save_dir = CURRENT_DIR
    results_dir = CURRENT_DIR / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    best_model_path = model_save_dir / "best_stgft.pth"

    print("\nStarting Training STGFT...\n")

    for epoch in range(epochs):
        model.train()
        train_loss = 0.0

        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            optimizer.zero_grad()
            pred = model(X_batch)
            loss = criterion(pred, y_batch)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        train_loss /= len(train_loader)

        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device)
                pred = model(X_batch)
                loss = criterion(pred, y_batch)
                val_loss += loss.item()

        val_loss /= len(val_loader)

        print(
            f"Epoch {epoch+1:02d}/{epochs} | "
            f"Train Loss = {train_loss:.5f} | "
            f"Validation Loss = {val_loss:.5f}"
        )

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            torch.save(model.state_dict(), best_model_path)
            # Also save a copy inside results/
            torch.save(model.state_dict(), results_dir / "best_stgft.pth")
            print("  --> Best Model Saved")
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"\nEarly stopping triggered after epoch {epoch+1} (patience={patience})")
                break

    print("\n" + "=" * 50)
    print("TRAINING COMPLETED")
    print("=" * 50)
    print(f"Best Validation Loss : {best_val_loss:.5f}")

    # ============================================
    # Evaluation on Validation Data
    # ============================================
    model.load_state_dict(torch.load(best_model_path, map_location=device))
    model.eval()

    with torch.no_grad():
        val_pred_scaled = model(X_val_tensor.to(device)).cpu().numpy()

    val_pred = scaler_y.inverse_transform(val_pred_scaled)
    val_actual = scaler_y.inverse_transform(y_val)

    # Save validation results
    np.save(results_dir / "prediction_val.npy", val_pred)
    np.save(results_dir / "actual_val.npy", val_actual)

    names = ["DO", "pH", "BOD"]

    print("\n" + "=" * 50)
    print("MODEL PERFORMANCE")
    print("=" * 50)

    for i in range(3):
        mae = mean_absolute_error(val_actual[:, i], val_pred[:, i])
        rmse = np.sqrt(mean_squared_error(val_actual[:, i], val_pred[:, i]))
        r2 = r2_score(val_actual[:, i], val_pred[:, i])

        print(f"\n{names[i]}")
        print(f"MAE  : {mae:.4f}")
        print(f"RMSE : {rmse:.4f}")
        print(f"R²   : {r2:.4f}")

    # ============================================
    # Evaluation on Unseen 2025 Test Data
    # ============================================
    X_2025_tensor = torch.tensor(X_2025_scaled, dtype=torch.float32).to(device)

    with torch.no_grad():
        pred_2025_scaled = model(X_2025_tensor).cpu().numpy()

    pred_2025 = scaler_y.inverse_transform(pred_2025_scaled)
    actual_2025 = y_2025_raw

    # Save 2025 test results
    np.save(results_dir / "prediction_2025.npy", pred_2025)
    np.save(results_dir / "actual_2025.npy", actual_2025)

    print("\n" + "=" * 50)
    print("2025 MODEL EVALUATION")
    print("=" * 50)
    print("Actual :", actual_2025.shape)
    print("Prediction :", pred_2025.shape)

    for i in range(3):
        mae_25 = mean_absolute_error(actual_2025[:, i], pred_2025[:, i])
        rmse_25 = np.sqrt(mean_squared_error(actual_2025[:, i], pred_2025[:, i]))
        r2_25 = r2_score(actual_2025[:, i], pred_2025[:, i])

        print(f"\n{names[i]}")
        print(f"MAE  : {mae_25:.4f}")
        print(f"RMSE : {rmse_25:.4f}")
        print(f"R²   : {r2_25:.4f}")

    print("\nEvaluation Completed")


if __name__ == "__main__":
    main()
