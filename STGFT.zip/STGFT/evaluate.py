"""
Evaluation Script for STGFT (Spatial-Temporal Graph Fusion Transformer)

Loads the trained STGFT model and evaluates on:
1. Validation dataset
2. Unseen 2025 Test dataset
"""

import sys
from pathlib import Path
import numpy as np
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
sys.path.append(str(CURRENT_DIR))

from model import STGFT


def load_dataset():
    processed_dir = PROJECT_ROOT / "River_Water_Quality_Project - Copy" / "Processed_Data"
    
    if (processed_dir / "X_val_scaled.npy").exists():
        X_val = np.load(processed_dir / "X_val_scaled.npy")
        y_val = np.load(processed_dir / "y_val_scaled.npy")
        scaler_X = joblib.load(processed_dir / "scaler_X.pkl")
        scaler_y = joblib.load(processed_dir / "scaler_y.pkl")
        X_2025_raw = np.load(processed_dir / "X_2025.npy")
        y_2025_raw = np.load(processed_dir / "y_2025.npy")
    else:
        raise FileNotFoundError(f"Processed dataset directory not found at {processed_dir}")

    samples_test, seq_len, num_feat = X_2025_raw.shape
    X_2025_scaled = scaler_X.transform(X_2025_raw.reshape(-1, num_feat)).reshape(samples_test, seq_len, num_feat)

    return X_val, y_val, X_2025_scaled, y_2025_raw, scaler_y


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    X_val, y_val, X_2025_scaled, y_2025_raw, scaler_y = load_dataset()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_path = CURRENT_DIR / "best_stgft.pth"

    if not model_path.exists():
        model_path = CURRENT_DIR / "results" / "best_stgft.pth"

    if not model_path.exists():
        raise FileNotFoundError(f"Model checkpoint not found. Please run train.py first: {model_path}")

    model = STGFT().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()

    print("=" * 50)
    print("VALIDATION DATA")
    print("=" * 50)
    print("X_val :", X_val.shape)
    print("y_val :", y_val.shape)

    # Validation evaluation
    X_val_tensor = torch.tensor(X_val, dtype=torch.float32).to(device)
    with torch.no_grad():
        val_pred_scaled = model(X_val_tensor).cpu().numpy()

    val_pred = scaler_y.inverse_transform(val_pred_scaled)
    val_actual = scaler_y.inverse_transform(y_val)

    names = ["DO", "pH", "BOD"]

    print("\n" + "=" * 50)
    print("MODEL PERFORMANCE")
    print("=" * 50)

    for i in range(3):
        mae = mean_absolute_error(val_actual[:, i], val_pred[:, i])
        rmse = np.sqrt(mean_squared_error(val_actual[:, i], val_pred[:, i]))
        r2 = r2_score(val_actual[:, i], val_pred[:, i])

        print(f"\n{names[i]}")
        print(f"MAE  : {mae:.4f}")
        print(f"RMSE : {rmse:.4f}")
        print(f"R²   : {r2:.4f}")

    # 2025 Test evaluation
    X_2025_tensor = torch.tensor(X_2025_scaled, dtype=torch.float32).to(device)
    with torch.no_grad():
        pred_2025_scaled = model(X_2025_tensor).cpu().numpy()

    pred_2025 = scaler_y.inverse_transform(pred_2025_scaled)
    actual_2025 = y_2025_raw

    print("\n" + "=" * 50)
    print("2025 MODEL EVALUATION")
    print("=" * 50)
    print("Actual :", actual_2025.shape)
    print("Prediction :", pred_2025.shape)

    for i in range(3):
        mae_25 = mean_absolute_error(actual_2025[:, i], pred_2025[:, i])
        rmse_25 = np.sqrt(mean_squared_error(actual_2025[:, i], pred_2025[:, i]))
        r2_25 = r2_score(actual_2025[:, i], pred_2025[:, i])

        print(f"\n{names[i]}")
        print(f"MAE  : {mae_25:.4f}")
        print(f"RMSE : {rmse_25:.4f}")
        print(f"R²   : {r2_25:.4f}")

    print("\nEvaluation Completed")


if __name__ == "__main__":
    main()
