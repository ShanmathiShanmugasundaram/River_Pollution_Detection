"""
Hybrid Deep Autoregression and Bidirectional LSTM Network (DeepAR + BiLSTM / DAFA-BiLSTM)
for Multivariate River Water Quality Forecasting.

Inspired by:
"Enhancing River Water Quality Prediction: A Hybrid Approach of Deep Autoregression and Bidirectional LSTM Networks"
D. Narmadha et al., Journal of Information Systems Engineering & Management (JISEM), 2025.

Architecture Overview:
1. DeepAR Module (Deep Autoregression):
   - Recurrent autoregressive network with recursive temporal feedback.
   - Outputs Gaussian distribution parameters (mean mu, standard deviation sigma) for multivariate parameters.
   - Produces rich autoregressive feature representations F_AR = [h_ar, mu, sigma].
2. Bidirectional LSTM (BiLSTM):
   - Multi-layer bidirectional LSTM processing sequences in both forward and backward temporal directions.
   - Captures both past momentum and context across the 12-month lookback window.
3. Deep Autoregression Feature Augmentation (DAFA) & Hierarchical Cross-Attention:
   - Integrates DeepAR autoregressive features to augment BiLSTM representations.
   - Cross-attention mechanism where BiLSTM queries attend to DeepAR autoregressive keys/values.
4. Gated Feature Fusion & Output Decoder:
   - Fuses bidirectional context and autoregressive distribution features.
   - Maps fused representations to forecast DO, pH, and BOD at time step t+1.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class DeepARCore(nn.Module):
    """
    Deep Autoregressive recurrent module.
    At each step t in [1, ..., T]:
      h_t = RNN(x_t, h_{t-1})
      mu_t = Linear(h_t)
      sigma_t = Softplus(Linear(h_t)) + epsilon
    Provides:
      - Autoregressive feature representations
      - Distribution parameters for probabilistic/autoregressive loss calculation
    """
    def __init__(self, num_features=3, hidden_dim=64, num_layers=2, dropout=0.1):
        super().__init__()
        self.num_features = num_features
        self.hidden_dim = hidden_dim
        
        self.rnn = nn.GRU(
            input_size=num_features,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        
        self.mu_head = nn.Linear(hidden_dim, num_features)
        self.sigma_head = nn.Linear(hidden_dim, num_features)

    def forward(self, x):
        # x: (batch_size, seq_len=12, num_features=3)
        h_seq, _ = self.rnn(x)  # (batch_size, seq_len, hidden_dim)
        
        # Predicted distribution parameters at each time step
        mu = self.mu_head(h_seq)        # (batch_size, seq_len, 3)
        sigma = F.softplus(self.sigma_head(h_seq)) + 1e-4  # (batch_size, seq_len, 3)
        
        # Deep Autoregressive feature concatenation: [h_seq, mu, sigma]
        ar_features = torch.cat([h_seq, mu, sigma], dim=-1)  # (batch_size, seq_len, hidden_dim + 6)
        
        return ar_features, mu, sigma


class BiLSTMEncoder(nn.Module):
    """
    Bidirectional LSTM module:
    Processes input sequences forward and backward to extract contextual temporal representations.
    """
    def __init__(self, num_features=3, hidden_dim=64, num_layers=2, dropout=0.1):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=num_features,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.out_dim = hidden_dim * 2  # Bidirectional

    def forward(self, x):
        # x: (batch_size, seq_len, num_features)
        h_seq, _ = self.lstm(x)  # (batch_size, seq_len, hidden_dim * 2)
        return h_seq


class HierarchicalCrossAttention(nn.Module):
    """
    Hierarchical Cross-Attention Module for Deep Autoregression Feature Augmentation (DAFA):
    Attends BiLSTM representations (Query) over DeepAR autoregressive features (Key, Value).
    """
    def __init__(self, bilstm_dim=128, ar_dim=70, embed_dim=64, num_heads=4, dropout=0.1):
        super().__init__()
        self.q_proj = nn.Linear(bilstm_dim, embed_dim)
        self.k_proj = nn.Linear(ar_dim, embed_dim)
        self.v_proj = nn.Linear(ar_dim, embed_dim)
        
        self.attn = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        self.norm = nn.LayerNorm(embed_dim)
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 2, embed_dim)
        )
        self.norm2 = nn.LayerNorm(embed_dim)

    def forward(self, h_bilstm, f_ar):
        # h_bilstm: (batch_size, seq_len, bilstm_dim)
        # f_ar: (batch_size, seq_len, ar_dim)
        q = self.q_proj(h_bilstm)
        k = self.k_proj(f_ar)
        v = self.v_proj(f_ar)
        
        attn_out, _ = self.attn(q, k, v)
        h = self.norm(q + attn_out)
        ffn_out = self.ffn(h)
        h = self.norm2(h + ffn_out)
        return h  # (batch_size, seq_len, embed_dim)


class DeepAR_BiLSTM(nn.Module):
    """
    DeepAR + BiLSTM Hybrid Network.
    
    Combines:
    1. DeepAR autoregressive recurrent module (probabilistic parameter estimation)
    2. Bidirectional LSTM network (bidirectional contextual encoding)
    3. Hierarchical Cross-Attention (DAFA feature augmentation)
    4. Gated Spatiotemporal Fusion
    5. Multivariate Output Head (DO, pH, BOD)
    """
    def __init__(
        self,
        num_features=3,
        seq_len=12,
        hidden_dim=64,
        bilstm_layers=2,
        deepar_layers=2,
        dropout=0.1
    ):
        super().__init__()
        self.num_features = num_features
        self.seq_len = seq_len
        self.hidden_dim = hidden_dim
        
        # 1. DeepAR Module
        self.deepar = DeepARCore(
            num_features=num_features,
            hidden_dim=hidden_dim,
            num_layers=deepar_layers,
            dropout=dropout
        )
        ar_dim = hidden_dim + num_features * 2  # hidden + mu + sigma
        
        # 2. BiLSTM Module
        self.bilstm = BiLSTMEncoder(
            num_features=num_features,
            hidden_dim=hidden_dim,
            num_layers=bilstm_layers,
            dropout=dropout
        )
        bilstm_dim = hidden_dim * 2
        
        # 3. DAFA Cross-Attention
        self.cross_attention = HierarchicalCrossAttention(
            bilstm_dim=bilstm_dim,
            ar_dim=ar_dim,
            embed_dim=hidden_dim,
            num_heads=4,
            dropout=dropout
        )
        
        # 4. Gated Feature Fusion
        self.bilstm_proj = nn.Linear(bilstm_dim, hidden_dim)
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Sigmoid()
        )
        
        # 5. Multivariate Prediction Head
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_features)
        )

    def forward(self, x, return_distribution=False):
        # x: (batch_size, 12, 3)
        # DeepAR Module: autoregressive features and distribution parameters
        f_ar, mu, sigma = self.deepar(x)
        
        # BiLSTM Module: bidirectional temporal representations
        h_bilstm = self.bilstm(x)
        
        # DAFA Cross-Attention: BiLSTM queries attend to DeepAR features
        h_cross = self.cross_attention(h_bilstm, f_ar)
        
        # Gated fusion between BiLSTM features and cross-attended DeepAR features
        h_bi_proj = self.bilstm_proj(h_bilstm)
        gate_val = self.gate(torch.cat([h_bi_proj, h_cross], dim=-1))
        fused = gate_val * h_bi_proj + (1.0 - gate_val) * h_cross  # (batch_size, seq_len, hidden_dim)
        
        # Extract final time step state
        fused_last = fused[:, -1, :]  # (batch_size, hidden_dim)
        
        # Predict target parameters (DO, pH, BOD)
        out = self.head(fused_last)  # (batch_size, 3)
        
        if return_distribution:
            return out, mu, sigma
        return out

    def compute_deepar_nll_loss(self, x, mu, sigma):
        """
        Negative Log-Likelihood (Gaussian NLL) for DeepAR autoregressive forecasting.
        L_NLL = mean( 0.5 * ((x - mu) / sigma)^2 + log(sigma) )
        """
        var = torch.clamp(sigma ** 2, min=1e-6)
        nll = 0.5 * ((x - mu) ** 2) / var + torch.log(sigma)
        return torch.mean(nll)


if __name__ == "__main__":
    model = DeepAR_BiLSTM()
    test_x = torch.randn(8, 12, 3)
    test_out, mu, sigma = model(test_x, return_distribution=True)
    nll = model.compute_deepar_nll_loss(test_x, mu, sigma)
    
    print("DeepAR + BiLSTM Model initialized successfully.")
    print(f"Input shape       : {test_x.shape}")
    print(f"Output shape      : {test_out.shape}")
    print(f"DeepAR mu shape   : {mu.shape}")
    print(f"DeepAR sigma shape: {sigma.shape}")
    print(f"DeepAR NLL loss   : {nll.item():.4f}")
    
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {total_params:,}")
